import React from 'react';
import { AlertTriangle, Bell } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Alert {
  id: string;
  type: 'temperature' | 'humidity' | 'gas';
  message: string;
  timestamp: string;
  severity: 'warning' | 'critical';
}

interface AlertBoxProps {
  alerts: Alert[];
}

const AlertBox: React.FC<AlertBoxProps> = ({ alerts }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300"
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Active Alerts</h2>
        <Bell className="w-5 h-5 text-gray-500" />
      </div>
      <div className="space-y-4 max-h-[300px] overflow-y-auto">
        <AnimatePresence>
          {alerts.map((alert) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className={`flex items-center space-x-3 p-4 rounded-lg ${
                alert.severity === 'critical' 
                  ? 'bg-gradient-to-r from-red-50 to-red-100 border-l-4 border-red-500' 
                  : 'bg-gradient-to-r from-yellow-50 to-yellow-100 border-l-4 border-yellow-500'
              }`}
            >
              <AlertTriangle className={`w-5 h-5 ${
                alert.severity === 'critical' ? 'text-red-500' : 'text-yellow-500'
              }`} />
              <div>
                <p className={`text-sm font-medium ${
                  alert.severity === 'critical' ? 'text-red-800' : 'text-yellow-800'
                }`}>
                  {alert.message}
                </p>
                <p className={`text-xs ${
                  alert.severity === 'critical' ? 'text-red-600' : 'text-yellow-600'
                }`}>
                  {alert.timestamp}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {alerts.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-8 text-gray-500"
          >
            <Bell className="w-12 h-12 mb-2 text-gray-300" />
            <p>No active alerts</p>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default AlertBox;