import React, { useState } from 'react';
import { Pencil, Trash2, Plus, Settings, ChevronDown, ChevronUp, Save } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Component {
  id: string;
  name: string;
}

interface Device {
  id: string;
  name: string;
  components: Component[];
  isExpanded?: boolean;
}

interface Product {
  id: string;
  name: string;
  devices: Device[];
  isExpanded?: boolean;
}

const ProductTable: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [newProduct, setNewProduct] = useState('');
  const [editingProduct, setEditingProduct] = useState<{ id: string; name: string } | null>(null);
  const [newDevice, setNewDevice] = useState('');
  const [editingDevice, setEditingDevice] = useState<{ productId: string; deviceId: string; name: string } | null>(null);
  const [newComponent, setNewComponent] = useState('');
  const [editingComponent, setEditingComponent] = useState<{ 
    productId: string; 
    deviceId: string; 
    componentId: string; 
    name: string 
  } | null>(null);

  // Product operations remain the same
  const handleAddProduct = () => {
    if (!newProduct.trim()) return;
    setProducts([...products, { 
      id: Date.now().toString(), 
      name: newProduct, 
      devices: [],
      isExpanded: true 
    }]);
    setNewProduct('');
  };

  const handleEditProduct = (id: string) => {
    const product = products.find(p => p.id === id);
    if (product) {
      setEditingProduct({ id, name: product.name });
    }
  };

  const handleSaveProduct = () => {
    if (!editingProduct) return;
    setProducts(products.map(p => 
      p.id === editingProduct.id ? { ...p, name: editingProduct.name } : p
    ));
    setEditingProduct(null);
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts(products.filter(p => p.id !== productId));
  };

  const handleToggleProduct = (productId: string) => {
    setProducts(products.map(p => 
      p.id === productId ? { ...p, isExpanded: !p.isExpanded } : p
    ));
  };

  // Device operations remain the same
  const handleAddDevice = (productId: string) => {
    if (!newDevice.trim()) return;
    setProducts(products.map(p => 
      p.id === productId 
        ? {
            ...p,
            devices: [...p.devices, { id: Date.now().toString(), name: newDevice, components: [], isExpanded: true }]
          }
        : p
    ));
    setNewDevice('');
  };

  const handleEditDevice = (productId: string, deviceId: string) => {
    const product = products.find(p => p.id === productId);
    const device = product?.devices.find(d => d.id === deviceId);
    if (device) {
      setEditingDevice({ productId, deviceId, name: device.name });
    }
  };

  const handleSaveDevice = () => {
    if (!editingDevice) return;
    setProducts(products.map(p => 
      p.id === editingDevice.productId 
        ? {
            ...p,
            devices: p.devices.map(d =>
              d.id === editingDevice.deviceId ? { ...d, name: editingDevice.name } : d
            )
          }
        : p
    ));
    setEditingDevice(null);
  };

  const handleDeleteDevice = (productId: string, deviceId: string) => {
    setProducts(products.map(p => 
      p.id === productId 
        ? {
            ...p,
            devices: p.devices.filter(d => d.id !== deviceId)
          }
        : p
    ));
  };

  const handleToggleDevice = (productId: string, deviceId: string) => {
    setProducts(products.map(p => 
      p.id === productId 
        ? {
            ...p,
            devices: p.devices.map(d => 
              d.id === deviceId ? { ...d, isExpanded: !d.isExpanded } : d
            )
          }
        : p
    ));
  };

  // Updated Component operations with CRUD
  const handleAddComponent = (productId: string, deviceId: string) => {
    if (!newComponent.trim()) return;
    setProducts(products.map(p => 
      p.id === productId 
        ? {
            ...p,
            devices: p.devices.map(d => 
              d.id === deviceId 
                ? {
                    ...d,
                    components: [...d.components, { 
                      id: Date.now().toString(), 
                      name: newComponent
                    }]
                  }
                : d
            )
          }
        : p
    ));
    setNewComponent('');
  };

  const handleEditComponent = (productId: string, deviceId: string, componentId: string) => {
    const product = products.find(p => p.id === productId);
    const device = product?.devices.find(d => d.id === deviceId);
    const component = device?.components.find(c => c.id === componentId);
    if (component) {
      setEditingComponent({ productId, deviceId, componentId, name: component.name });
    }
  };

  const handleSaveComponent = () => {
    if (!editingComponent) return;
    setProducts(products.map(p => 
      p.id === editingComponent.productId 
        ? {
            ...p,
            devices: p.devices.map(d => 
              d.id === editingComponent.deviceId 
                ? {
                    ...d,
                    components: d.components.map(c =>
                      c.id === editingComponent.componentId ? { ...c, name: editingComponent.name } : c
                    )
                  }
                : d
            )
          }
        : p
    ));
    setEditingComponent(null);
  };

  const handleDeleteComponent = (productId: string, deviceId: string, componentId: string) => {
    setProducts(products.map(p => 
      p.id === productId 
        ? {
            ...p,
            devices: p.devices.map(d => 
              d.id === deviceId 
                ? {
                    ...d,
                    components: d.components.filter(c => c.id !== componentId)
                  }
                : d
            )
          }
        : p
    ));
  };

  return (
    <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 p-6">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Product Management</h2>
      
      {/* Add Product Form */}
      <div className="mb-6">
        <div className="flex space-x-2">
          <input
            type="text"
            value={newProduct}
            onChange={(e) => setNewProduct(e.target.value)}
            placeholder="Add new product..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleAddProduct}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-300 flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span>Add Product</span>
          </motion.button>
        </div>
      </div>

      {/* Products List */}
      <div className="space-y-4">
        <AnimatePresence>
          {products.map(product => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="border border-gray-200 rounded-lg overflow-hidden hover:border-blue-300 transition-colors duration-300"
            >
              {/* Product Header */}
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => handleToggleProduct(product.id)}
                    className="text-gray-500 hover:text-gray-700 transition-colors"
                  >
                    {product.isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </button>
                  {editingProduct?.id === product.id ? (
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={editingProduct.name}
                        onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                        className="px-2 py-1 border rounded"
                      />
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={handleSaveProduct}
                        className="text-green-600 hover:text-green-700"
                      >
                        <Save className="w-4 h-4" />
                      </motion.button>
                    </div>
                  ) : (
                    <h3 className="font-semibold text-lg text-gray-800">{product.name}</h3>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleEditProduct(product.id)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
                  >
                    <Pencil className="w-4 h-4" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleDeleteProduct(product.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-full transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </motion.button>
                </div>
              </div>

              {/* Devices Section */}
              <AnimatePresence>
                {product.isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-4 bg-gray-50"
                  >
                    {/* Add Device Form */}
                    <div className="mb-4 ml-8">
                      <div className="flex space-x-2">
                        <input
                          type="text"
                          value={newDevice}
                          onChange={(e) => setNewDevice(e.target.value)}
                          placeholder="Add new device..."
                          className="flex-1 px-3 py-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => handleAddDevice(product.id)}
                          className="px-3 py-1 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg hover:from-green-600 hover:to-green-700 transition-all duration-300 flex items-center space-x-1"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Add Device</span>
                        </motion.button>
                      </div>
                    </div>

                    {/* Devices List */}
                    <div className="space-y-3 ml-8">
                      {product.devices.map(device => (
                        <motion.div
                          key={device.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          className="border border-gray-200 rounded-lg bg-white"
                        >
                          {/* Device Header */}
                          <div className="p-3 flex items-center justify-between bg-gradient-to-r from-blue-50 to-blue-100">
                            <div className="flex items-center space-x-2">
                              <button
                                onClick={() => handleToggleDevice(product.id, device.id)}
                                className="text-gray-500 hover:text-gray-700"
                              >
                                {device.isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                              </button>
                              {editingDevice?.deviceId === device.id ? (
                                <div className="flex items-center space-x-2">
                                  <input
                                    type="text"
                                    value={editingDevice.name}
                                    onChange={(e) => setEditingDevice({ ...editingDevice, name: e.target.value })}
                                    className="px-2 py-1 border rounded text-sm"
                                  />
                                  <motion.button
                                    whileHover={{ scale: 1.1 }}
                                    whileTap={{ scale: 0.9 }}
                                    onClick={handleSaveDevice}
                                    className="text-green-600 hover:text-green-700"
                                  >
                                    <Save className="w-3 h-3" />
                                  </motion.button>
                                </div>
                              ) : (
                                <span className="text-sm font-medium text-gray-700">{device.name}</span>
                              )}
                            </div>
                            <div className="flex items-center space-x-1">
                              <motion.button
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                                onClick={() => handleEditDevice(product.id, device.id)}
                                className="p-1 text-blue-600 hover:bg-blue-50 rounded-full"
                              >
                                <Pencil className="w-3 h-3" />
                              </motion.button>
                              <motion.button
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                                onClick={() => handleDeleteDevice(product.id, device.id)}
                                className="p-1 text-red-600 hover:bg-red-50 rounded-full"
                              >
                                <Trash2 className="w-3 h-3" />
                              </motion.button>
                            </div>
                          </div>

                          {/* Components Section */}
                          <AnimatePresence>
                            {device.isExpanded && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                exit={{ opacity: 0, height: 0 }}
                                className="p-3 space-y-2"
                              >
                                {/* Add Component Form */}
                                <div className="flex space-x-2 mb-3">
                                  <input
                                    type="text"
                                    value={newComponent}
                                    onChange={(e) => setNewComponent(e.target.value)}
                                    placeholder="Add new component..."
                                    className="flex-1 px-2 py-1 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                  />
                                  <motion.button
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                    onClick={() => handleAddComponent(product.id, device.id)}
                                    className="px-2 py-1 bg-gradient-to-r from-purple-500 to-purple-600 text-white text-sm rounded-lg hover:from-purple-600 hover:to-purple-700 transition-all duration-300 flex items-center space-x-1"
                                  >
                                    <Plus className="w-3 h-3" />
                                    <span>Add Component</span>
                                  </motion.button>
                                </div>

                                {/* Components List */}
                                <div className="space-y-2">
                                  {device.components.map(component => (
                                    <motion.div
                                      key={component.id}
                                      initial={{ opacity: 0, x: -10 }}
                                      animate={{ opacity: 1, x: 0 }}
                                      exit={{ opacity: 0, x: -10 }}
                                      className="flex items-center justify-between p-2 bg-gray-50 rounded-lg text-sm"
                                    >
                                      {editingComponent?.componentId === component.id ? (
                                        <div className="flex items-center space-x-2">
                                          <input
                                            type="text"
                                            value={editingComponent.name}
                                            onChange={(e) => setEditingComponent({ ...editingComponent, name: e.target.value })}
                                            className="px-2 py-1 border rounded text-sm"
                                          />
                                          <motion.button
                                            whileHover={{ scale: 1.1 }}
                                            whileTap={{ scale: 0.9 }}
                                            onClick={handleSaveComponent}
                                            className="text-green-600 hover:text-green-700"
                                          >
                                            <Save className="w-3 h-3" />
                                          </motion.button>
                                        </div>
                                      ) : (
                                        <span className="text-gray-700">{component.name}</span>
                                      )}
                                      <div className="flex items-center space-x-1">
                                        <motion.button
                                          whileHover={{ scale: 1.1 }}
                                          whileTap={{ scale: 0.9 }}
                                          onClick={() => handleEditComponent(product.id, device.id, component.id)}
                                          className="p-1 text-blue-600 hover:bg-blue-50 rounded-full"
                                        >
                                          <Pencil className="w-3 h-3" />
                                        </motion.button>
                                        <motion.button
                                          whileHover={{ scale: 1.1 }}
                                          whileTap={{ scale: 0.9 }}
                                          onClick={() => handleDeleteComponent(product.id, device.id, component.id)}
                                          className="p-1 text-red-600 hover:bg-red-50 rounded-full"
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </motion.button>
                                      </div>
                                    </motion.div>
                                  ))}
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ProductTable;