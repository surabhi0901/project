import React from 'react';
import { LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';

interface StatusCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  bgColor: string;
  textColor: string;
  isAlert?: boolean;
}

const StatusCard: React.FC<StatusCardProps> = ({ title, value, icon: Icon, bgColor, textColor, isAlert }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className={`bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 ${
        isAlert ? 'border-2 border-red-500 animate-pulse' : ''
      }`}
    >
      <div className="flex items-center space-x-4">
        <div className={`p-3 ${bgColor} rounded-full`}>
          <Icon className={`w-6 h-6 ${textColor}`} />
        </div>
        <div>
          <p className="text-sm text-gray-600 font-medium">{title}</p>
          <p className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-gray-900 to-gray-600">
            {value}
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default StatusCard;