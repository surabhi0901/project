import React, { useState, useEffect } from 'react';
import { Thermometer, Droplets, Wind } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import StatusCard from './StatusCard';
import LineGraph from './LineGraph';
import AlertBox from './AlertBox';
import ChatBot from './ChatBot';
import ProductTable from './ProductTable';

// Thresholds for alerts
const THRESHOLDS = {
  temperature: { min: 18, max: 24 }, // °C
  humidity: { min: 35, max: 55 }, // %
  gas: { max: 50 } // ppm
};

const Dashboard = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [currentData, setCurrentData] = useState({
    temperature: 22,
    humidity: 45,
    gas: 20
  });
  
  const [historicalData, setHistoricalData] = useState({
    temperature: [] as { time: string; value: number }[],
    humidity: [] as { time: string; value: number }[],
    gas: [] as { time: string; value: number }[]
  });

  const [alerts, setAlerts] = useState<any[]>([]);

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      const time = new Date().toLocaleTimeString();
      const newTemp = currentData.temperature + (Math.random() - 0.5) * 2;
      const newHumidity = currentData.humidity + (Math.random() - 0.5) * 3;
      const newGas = currentData.gas + (Math.random() - 0.5) * 5;

      // Update current values
      setCurrentData({
        temperature: Number(newTemp.toFixed(1)),
        humidity: Number(newHumidity.toFixed(1)),
        gas: Number(newGas.toFixed(1))
      });

      // Update historical data
      setHistoricalData(prev => ({
        temperature: [...prev.temperature.slice(-20), { time, value: newTemp }],
        humidity: [...prev.humidity.slice(-20), { time, value: newHumidity }],
        gas: [...prev.gas.slice(-20), { time, value: newGas }]
      }));

      // Check for alerts
      if (newTemp > THRESHOLDS.temperature.max) {
        addAlert('temperature', `High temperature: ${newTemp.toFixed(1)}°C`, 'critical');
      } else if (newTemp < THRESHOLDS.temperature.min) {
        addAlert('temperature', `Low temperature: ${newTemp.toFixed(1)}°C`, 'warning');
      }

      if (newHumidity > THRESHOLDS.humidity.max) {
        addAlert('humidity', `High humidity: ${newHumidity.toFixed(1)}%`, 'critical');
      } else if (newHumidity < THRESHOLDS.humidity.min) {
        addAlert('humidity', `Low humidity: ${newHumidity.toFixed(1)}%`, 'warning');
      }

      if (newGas > THRESHOLDS.gas.max) {
        addAlert('gas', `Dangerous gas levels: ${newGas.toFixed(1)} ppm`, 'critical');
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [currentData]);

  const addAlert = (type: string, message: string, severity: 'warning' | 'critical') => {
    const newAlert = {
      id: Date.now().toString(),
      type,
      message,
      timestamp: new Date().toLocaleTimeString(),
      severity
    };
    setAlerts(prev => [newAlert, ...prev].slice(0, 5));
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Warehouse Monitoring System</h1>
          <p className="text-gray-600">Real-time environmental monitoring and control</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatusCard
            title="Temperature"
            value={`${currentData.temperature}°C`}
            icon={Thermometer}
            bgColor="bg-green-100"
            textColor="text-green-600"
            isAlert={currentData.temperature > THRESHOLDS.temperature.max || currentData.temperature < THRESHOLDS.temperature.min}
          />
          <StatusCard
            title="Humidity"
            value={`${currentData.humidity}%`}
            icon={Droplets}
            bgColor="bg-blue-100"
            textColor="text-blue-600"
            isAlert={currentData.humidity > THRESHOLDS.humidity.max || currentData.humidity < THRESHOLDS.humidity.min}
          />
          <StatusCard
            title="Gas Level"
            value={`${currentData.gas} ppm`}
            icon={Wind}
            bgColor="bg-yellow-100"
            textColor="text-yellow-600"
            isAlert={currentData.gas > THRESHOLDS.gas.max}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <LineGraph
            title="Temperature History"
            data={historicalData.temperature}
            color="#10B981"
            unit="°C"
          />
          <LineGraph
            title="Humidity History"
            data={historicalData.humidity}
            color="#3B82F6"
            unit="%"
          />
          <LineGraph
            title="Gas Level History"
            data={historicalData.gas}
            color="#F59E0B"
            unit=" ppm"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <AlertBox alerts={alerts} />
          <ProductTable />
        </div>

        <AnimatePresence>
          {isChatOpen && (
            <motion.div
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 100 }}
              className="fixed bottom-4 right-4 w-96 bg-white rounded-xl shadow-lg overflow-hidden z-50"
            >
              <ChatBot onClose={() => setIsChatOpen(false)} />
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="fixed bottom-4 right-4 p-4 bg-blue-600 text-white rounded-full shadow-lg z-50"
        >
          {isChatOpen ? '×' : '?'}
        </motion.button>
      </div>
    </div>
  );
};

export default Dashboard;